import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { BatteryThreeQuartersIcon } from './BatteryThreeQuartersIcon';
import { Ellipse2Icon } from './Ellipse2Icon';
import { Ellipse2Icon2 } from './Ellipse2Icon2';
import { Ellipse2Icon3 } from './Ellipse2Icon3';
import { Frame1_stateOff } from './Frame1_stateOff/Frame1_stateOff';
import { FrameIcon } from './FrameIcon';
import { FrameIcon2 } from './FrameIcon2';
import { FrameIcon3 } from './FrameIcon3';
import { FrameIcon4 } from './FrameIcon4';
import { FrameIcon5 } from './FrameIcon5';
import { FrameIcon6 } from './FrameIcon6';
import { FrameIcon7 } from './FrameIcon7';
import { FrameIcon8 } from './FrameIcon8';
import { FrameIcon9 } from './FrameIcon9';
import { Group45907Icon } from './Group45907Icon';
import { Line3Icon } from './Line3Icon';
import { SignalIcon } from './SignalIcon';
import classes from './Travel.module.css';
import { WifiIcon } from './WifiIcon';

interface Props {
  className?: string;
}
/* @figmaId 5:17 */
export const Travel: FC<Props> = memo(function Travel(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.rectangle608}></div>
      <div className={classes.rectangle609}></div>
      <div className={classes.yourLocation}>Your Location</div>
      <div className={classes.yourLocation2}>Your Location</div>
      <div className={classes.destination}>Destination &gt;</div>
      <div className={classes.frame}>
        <FrameIcon className={classes.icon4} />
      </div>
      <div className={classes.saveTime}>Save Time</div>
      <Frame1_stateOff
        className={classes.frame2}
        classes={{ ellipse2: classes.ellipse2 }}
        swap={{
          ellipse2: (
            <div className={classes.ellipse2}>
              <Ellipse2Icon className={classes.icon} />
            </div>
          ),
        }}
      />
      <div className={classes.saveMoney}>Save Money</div>
      <Frame1_stateOff
        className={classes.frame22}
        classes={{ ellipse2: classes.ellipse22 }}
        swap={{
          ellipse2: (
            <div className={classes.ellipse22}>
              <Ellipse2Icon2 className={classes.icon2} />
            </div>
          ),
        }}
      />
      <div className={classes.womenSafe}>Women Safe</div>
      <Frame1_stateOff
        className={classes.frame23}
        classes={{ ellipse2: classes.ellipse23 }}
        swap={{
          ellipse2: (
            <div className={classes.ellipse23}>
              <Ellipse2Icon3 className={classes.icon3} />
            </div>
          ),
        }}
      />
      <div className={classes.frame3}>
        <FrameIcon2 className={classes.icon5} />
      </div>
      <div className={classes.group45907}>
        <Group45907Icon className={classes.icon6} />
      </div>
      <div className={classes.line2}></div>
      <div className={classes.rectangle9}></div>
      <div className={classes.frame4}>
        <FrameIcon3 className={classes.icon7} />
      </div>
      <div className={classes.profile}>Profile</div>
      <div className={classes.line3}>
        <Line3Icon className={classes.icon8} />
      </div>
      <div className={classes.eTicket}>e-ticket</div>
      <div className={classes.frame5}>
        <FrameIcon4 className={classes.icon9} />
      </div>
      <div className={classes.mAPS}>MAPS</div>
      <div className={classes.travel}>travel</div>
      <div className={classes.frame6}>
        <FrameIcon5 className={classes.icon10} />
      </div>
      <div className={classes.frame7}>
        <FrameIcon6 className={classes.icon11} />
      </div>
      <div className={classes.frame8}>
        <FrameIcon7 className={classes.icon12} />
      </div>
      <div className={classes.line1}></div>
      <div className={classes.rectangle10}></div>
      <div className={classes.wifi}>
        <WifiIcon className={classes.icon13} />
      </div>
      <div className={classes.batteryThreeQuarters}>
        <BatteryThreeQuartersIcon className={classes.icon14} />
      </div>
      <div className={classes.signal}>
        <SignalIcon className={classes.icon15} />
      </div>
      <div className={classes._430}>4:30</div>
      <div className={classes.frame9}>
        <FrameIcon8 className={classes.icon16} />
      </div>
      <div className={classes.frame10}>
        <FrameIcon9 className={classes.icon17} />
      </div>
      <div className={classes.image1}></div>
    </div>
  );
});
