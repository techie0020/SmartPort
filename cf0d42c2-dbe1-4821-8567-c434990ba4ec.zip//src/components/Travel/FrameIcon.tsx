import { memo, SVGProps } from 'react';

const FrameIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 35 25' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M23.8636 12.8289H6.36365M23.8636 6.57895H6.36365M23.8636 19.0789H6.36365'
      stroke='#0A2472'
      strokeWidth={1.5}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(FrameIcon);
export { Memo as FrameIcon };
