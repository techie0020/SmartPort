import { memo, SVGProps } from 'react';

const Group45907Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 20 59' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M10 49.8333C11.3807 49.8333 12.5 48.7141 12.5 47.3333C12.5 45.9526 11.3807 44.8333 10 44.8333C8.61925 44.8333 7.5 45.9526 7.5 47.3333C7.5 48.7141 8.61925 49.8333 10 49.8333Z'
      stroke='#B51010'
      strokeOpacity={0.8}
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path
      d='M10 57.3333C13.3333 54 16.6667 51.0153 16.6667 47.3333C16.6667 43.6514 13.6819 40.6667 10 40.6667C6.3181 40.6667 3.33333 43.6514 3.33333 47.3333C3.33333 51.0153 6.66667 54 10 57.3333Z'
      stroke='#B51010'
      strokeOpacity={0.8}
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <path
      d='M9.5 15C13.6423 15 17 11.6423 17 7.5C17 3.35787 13.6423 0 9.5 0C5.35775 0 2 3.35787 2 7.5C2 11.6423 5.35775 15 9.5 15Z'
      stroke='#446BF6'
      strokeOpacity={0.55}
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
    <line
      x1={9.75}
      y1={18.75}
      x2={9.75}
      y2={37.25}
      stroke='black'
      strokeWidth={1.5}
      strokeLinecap='round'
      strokeDasharray='2 3'
    />
  </svg>
);

const Memo = memo(Group45907Icon);
export { Memo as Group45907Icon };
