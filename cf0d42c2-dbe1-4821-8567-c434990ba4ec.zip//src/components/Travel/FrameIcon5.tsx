import { memo, SVGProps } from 'react';

const FrameIcon5 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 19 20' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M3.66673 14.5671H11.3334C13.8739 14.5671 15.9334 12.8095 15.9334 10.6414C15.9334 8.47335 13.8739 6.71576 11.3334 6.71576H3.66673M3.66673 14.5671L6.7334 17.1842M3.66673 14.5671L6.7334 11.95'
      stroke='#0A2472'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(FrameIcon5);
export { Memo as FrameIcon5 };
