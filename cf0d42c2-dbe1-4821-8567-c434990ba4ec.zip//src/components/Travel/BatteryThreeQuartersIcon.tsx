import { memo, SVGProps } from 'react';

const BatteryThreeQuartersIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 23 23' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_83_37)'>
      <path
        d='M19.3399 8.27528V10.5506H20.4775V12.8258H19.3399V15.1011H2.27528V8.27528H19.3399ZM19.9087 6H1.70646C0.763997 6 0 6.764 0 7.70646V15.6699C0 16.6124 0.763997 17.3764 1.70646 17.3764H19.9087C20.8512 17.3764 21.6152 16.6124 21.6152 15.6699V15.1011H21.8996C22.3708 15.1011 22.7528 14.7191 22.7528 14.2479V9.12851C22.7528 8.65728 22.3708 8.27528 21.8996 8.27528H21.6152V7.70646C21.6152 6.764 20.8512 6 19.9087 6ZM14.7893 9.41292H3.41292V13.9635H14.7893V9.41292Z'
        fill='black'
      />
    </g>
    <defs>
      <clipPath id='clip0_83_37'>
        <rect width={22.7528} height={22.7528} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(BatteryThreeQuartersIcon);
export { Memo as BatteryThreeQuartersIcon };
