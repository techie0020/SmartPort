import { memo, SVGProps } from 'react';

const FrameIcon6 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 19 20' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M15.3333 9.86447H7.6666C5.1261 9.86447 3.0666 11.6221 3.0666 13.7901C3.0666 15.9582 5.1261 17.7158 7.6666 17.7158M15.3333 9.86447L12.2666 7.24737M15.3333 9.86447L12.2666 12.4816'
      stroke='#0A2472'
      strokeWidth={2}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(FrameIcon6);
export { Memo as FrameIcon6 };
