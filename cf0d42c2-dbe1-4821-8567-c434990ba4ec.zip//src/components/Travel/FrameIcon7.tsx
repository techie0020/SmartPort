import { memo, SVGProps } from 'react';

const FrameIcon7 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 23 21' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g clipPath='url(#clip0_83_33)'>
      <path
        d='M8.62501 15.75L1.91667 19.25V5.25L8.62501 1.75M8.62501 15.75L15.3333 19.25M8.62501 15.75V1.75M8.62501 1.75L15.3333 5.25M15.3333 19.25L21.0833 15.75V1.75L15.3333 5.25M15.3333 19.25V5.25'
        stroke='#0A2472'
        strokeWidth={2}
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </g>
    <defs>
      <clipPath id='clip0_83_33'>
        <rect width={23} height={21} fill='white' />
      </clipPath>
    </defs>
  </svg>
);

const Memo = memo(FrameIcon7);
export { Memo as FrameIcon7 };
