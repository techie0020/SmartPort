import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { Ellipse2Icon } from './Ellipse2Icon';
import classes from './Frame1_stateOff.module.css';

interface Props {
  className?: string;
  classes?: {
    ellipse2?: string;
    root?: string;
  };
  swap?: {
    ellipse2?: ReactNode;
  };
}
/* @figmaId 9:30 */
export const Frame1_stateOff: FC<Props> = memo(function Frame1_stateOff(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={`${props.classes?.ellipse2 || ''} ${classes.ellipse2}`}>
        {props.swap?.ellipse2 || <Ellipse2Icon className={classes.icon} />}
      </div>
    </div>
  );
});
