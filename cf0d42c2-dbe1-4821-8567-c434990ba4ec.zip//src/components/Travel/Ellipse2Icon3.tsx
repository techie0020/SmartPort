import { memo, SVGProps } from 'react';

const Ellipse2Icon3 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 22 20' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={11.0884} cy={9.82759} rx={10.2435} ry={9.71552} fill='white' />
  </svg>
);

const Memo = memo(Ellipse2Icon3);
export { Memo as Ellipse2Icon3 };
